---
name: d2-prism-dual-captions
description: Render approved D2 PRISM English subtitles using small Inter SemiBold support text and large electric-orange Anton 3D keywords for Tamil/Tanglish vertical Reels.
---

# D2 PRISM — approved dual-font caption skill

**Must use the approved examples** in `references/APPROVED_DUAL_FONT_STYLE_REFERENCE.mp4` and `D2_PRISM_APPROVED_DUAL_FONT_STYLE.json`. The user chose the latest corrected two-font version. The older Barlow-only preset is no longer the default.

## Steps
1. Verify source file `source/NEXT_REEL_FOR_CLAUDE.mp4` with ffprobe. It is an upload-friendly, compressed 1080x1920 copy, approximately 53s. Don't treat compression artifacts as a reason to redesign.
2. Reuse any existing local faster-whisper installation/model, else install only minimal necessary tooling. Generate source Tamil/Tanglish transcript with time spans and uncertainty flags. Confirm numbers and technical terms where possible; don't guess.
3. Make a separate natural-English caption timeline using corresponding phrase windows, not force-aligned word timings in translated English. Caption groups typically 2–4 words, at most 5. Keep one prominent orange keyword per group.
4. Use approved visual hierarchy: small uppercase white Inter SemiBold line above large uppercase orange Anton keyword, deep-navy restrained 3D extrusion and subtle pop; use Hero impact sparingly. Reconstruct from the actual video reference rather than inventing style.
5. Inspect all shots and screenshot graphics. At ~18–22s the calorie-calculator UI occupies much of the frame: don't obstruct its controls, numbers or labels. If there's no clear space, use a small caption elsewhere, or omit redundant text while preserving overall meaning and timing in adjacent phrases.
6. Test a talking-head section and calculator cutaway before a full render. Choose one 8–10s preview demonstrating both if possible. Save a sample MP4 and caption JSON/SRT. Flag any uncertain transcript values to the user.
7. Only after approval, produce full 1080x1920 H.264/AAC video and portable renderer/preset ZIP. Audio and visual cuts must match the source exactly unless explicitly approved. Avoid black frames and clipping.
8. Update repo-root `CLAUDE.md` and this skill when the user approves any material change to the caption style.

## Quality checks
- Correct English and phrase timing, especially at cuts/pauses.
- Highlighted keyword fits horizontally, no squeezing/stretching. Shrink or rephrase/split naturally rather than edge clipping.
- Don't overlap chin/hands, face or on-screen calculator panels. Mobile-safe margins.
- Keep original audio, duration and scene order. Verify output via contact sheet and playback or acknowledge if not fully watched.
- Budget tokens. Reuse existing code/assets. No unrelated repository work or repeated push attempts.
