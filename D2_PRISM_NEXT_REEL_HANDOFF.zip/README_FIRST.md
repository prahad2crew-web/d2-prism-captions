# D2 PRISM — next Reel Claude handoff

This archive is designed for the existing private `d2-prism-captions` GitHub repository, so Claude Code cloud can transcribe and edit the uploaded media without access to Google Drive tokens.

Included:
- `source/NEXT_REEL_FOR_CLAUDE.mp4`: compressed, full 53-second new video with speech; 1080×1920, 30fps. Used for cloud editing tests. Keep the original 63MB MP4 separately for the highest-quality final if desired.
- `references/APPROVED_DUAL_FONT_STYLE_REFERENCE.mp4`: a short silent clip cut from the user's previously approved dual-font caption video, showing real font and animation styling.
- `references/approved_default_weight.jpg` and `references/approved_weight_option.jpg`: actual approved caption-frame examples.
- `D2_PRISM_APPROVED_DUAL_FONT_STYLE.json`: visual styling and layout constraints.
- `CLAUDE.md`: persistent project instruction file; Claude Code reads it from repository root after unpacking.
- `.claude/skills/d2-prism-dual-captions/SKILL.md`: reusable project skill, read when generating D2 PRISM captions.
- `CLAUDE_START_HERE.txt`: copy/paste prompt to Claude Code.

**How to use from a phone:**
1. Upload this ZIP to your PRIVATE `d2-prism-captions` GitHub repository using browser Add file -> Upload files (archive was kept below the 25MiB browser cap).
2. In the existing Claude Code cloud session or new session connected to that repository, paste the content of `CLAUDE_START_HERE.txt` (also included in this ZIP).
3. Claude must extract the ZIP, read CLAUDE.md and the skill, then run transcription and create ONE preview. Do not approve rendering the whole video until you review the preview.
4. When the style and transcript are approved, request a downloadable full-quality MP4 plus the updated reusable preset. If the compressed upload quality is insufficient, supply the original source through a cloud path that the renderer actually can download.

**Important limitations:** This handoff does NOT contain a transcription of the new video, because a working speech-to-text model wasn't available in the preparation environment. Claude must transcribe the actual speech. No captions or medical claims have been guessed.

**Font licensing:** Fonts are NOT included in this ZIP. Use legitimately sourced Inter SemiBold and Anton from their official open-source distributions if the cloud system does not already have them. The actual reference video contains only rendered pixels, not font files.

**Privacy:** Private GitHub repository recommended. Do not post video or package publicly, and don't share OAuth tokens.
